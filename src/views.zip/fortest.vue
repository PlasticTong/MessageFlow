<template>
     <button class="button-common button-common-large" @click="importFile()">导入</button>


    <div class="fortest-all">
        <!-- <el-row>
        <el-col :span = "6">
        <el-card  style="height:100%" shadow="hover">
            <timechooser></timechooser>
        </el-card>
      </el-col>
      <el-col :span = "18">
        <el-row>
        <el-card shadow="hover">
            <mtree></mtree>
          </el-card>
        </el-row>
        <el-row>
          <el-col :span = "12">
            <el-card shadow="hover">
          <martree></martree>
          </el-card>
          </el-col>
          <el-col :span = "12"><el-card shadow="hover">
            <dagre></dagre> 
          </el-card></el-col>
        </el-row>
      </el-col>
      </el-row> -->
        <div class="timechooser">
            <timechooser></timechooser>
        </div>
        <div>
            <div class="mtree">
                <mtree></mtree>
            </div>
                <div class = "fortest">
                    <div class="martree">
                        <martree></martree>
                    </div>
                    <div class="dagre">
                        <dagre></dagre>
                    </div>
                </div>
        </div>
    </div>
</template>

<script setup>
import dagre from "../views/degreeTree.vue"
import martree from "../views/markovTree.vue"
import mtree from "../views/mestree.vue"
import timechooser from "./timechooser.vue";
import store from "../store/mesinfo"

function importFile() {
  var inputObj = document.createElement('input');
  inputObj.setAttribute('type', 'file');

  inputObj.addEventListener('change', function() {
    var file = inputObj.files[0];
    console.log(file); // 输出文件对象

    // 获取文件属性
    console.log(file.name); // 输出文件名
    console.log(file.size); // 输出文件大小（字节数）
    console.log(file.type); // 输出文件类型

    // 读取文件内容
    var reader = new FileReader();
    reader.onload = function(e) {
      var fileContent = e.target.result;
      console.log(fileContent); // 输出文件内容
      store.state.mesinfo = fileContent
      store.state.mesinfo2 = fileContent

    };
    reader.readAsText(file); // 以文本形式读取文件内容
  });

  inputObj.click();
}



</script>

<style lang="scss" scoped>

.fortest {
    display: flex;
    flex-direction: row;
}
.fortest-all {
    display: flex;
    flex-direction: row;
    background-color:#8ac9e2;
    height:1710px;
}

.timechooser {
    margin: 4px;
    // border: 1px solid #eebb55;
    height: 1700px;
    background-color: white;
}

.mtree {
    margin: 4px;
    background-color: white;
    height:720px
}
.martree{
    margin: 4px;
    flex-grow: 1;
    width: 10%;
    background-color: white;
}

.dagre{
    margin: 4px;
    flex-grow: 1;
    width: 10%;
    background-color: white;
}

.button-common-large {
  font-size: 20px;
  padding: 10px 20px;
}


//   .container :nth-child(1) {
//     background-color: #E3ABB3;
//     height: 100px; // 第一个项目给定固定高度 100px；
//   }
//   .container :nth-child(2) {
//     background-color: #9DC54B;

//   }
//   .container :nth-child(3) {
//     background-color: #1FBEE7;
//     height: 300px;

//   }</style>